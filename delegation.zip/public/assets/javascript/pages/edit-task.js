// Get the current URL

// const flatpickr = require("flatpickr");

const date = new Date();

let day = date.getDate();

flatpickr("#start_date", {
    "locale": {
        // "firstDayOfWeek": 1 // start week on Monday
    }

});

flatpickr("#end_date", {});

$('#start_date').change(function () {
    let selected = $(this).val();
    let month = selected.split('-')[1];
    let year = selected.split('-')[0];
    if (selected.split('-')[2] === '01') {

        let newdate = year + '-' + month + '-15';
        $('#end_date').val(newdate);
    } else if (selected.split('-')[2] === '16') {
        let newdate = year + '-' + month + '-' + lastday(year, month - 1);
        $('#end_date').val(newdate);
    }
});
var lastday = function (y, m) {
    // Create a new Date object representing the last day of the specified month
    // By passing m + 1 as the month parameter and 0 as the day parameter, it represents the last day of the specified month
    return new Date(y, m + 1, 0).getDate();
}

// Get the current URL path
const path = window.location.pathname;
// Split the path to get the segments
const segments = path.split('/');


let result_arr = [];
console.log('result_arr | ', result_arr)
$(document).ready(function () {


// Assuming the ID is the last segment
    const id = segments.pop() || segments.pop();  // handle potential trailing slash
    console.log('id: ', id)

    if (id) {
        console.log('Hiii')
        $.ajax({
            type: 'GET',
            url: BASE_URL + '/tasks/medical_needs/' + id,
            // data: {'TASK_ID': id, "_token": TOKEN},
            dataType: 'json',
            async:false,
            success: function (mm) {
                console.log('MMM: ', mm)
                result_arr = mm;
                console.log('TR::: ', result_arr)

            },
            error(e) {
                console.log('error: ', e)
            }
        })
    }
    console.log('hooooo')
    // Initialize the repeater
    $('#medical_needs_repeater').repeater({
        initEmpty: false,
        defaultValues: {
            'human_type_id': '',
            'specialization_id': '',
            'count': '',
            'note': ''
        },
        isFirstItemUndeletable: true,
        show: function () {
            $(this).slideDown();
            $(this).find('.need-human-type').val('');
            $(this).find('.need-specialization').empty().append('<option value="">Choose an option</option>');
        },
        hide: function (deleteElement) {
            $(this).slideUp(deleteElement);
        },
        ready: function (setIndexes) {

            let i = 0;

            $(document).on('change', '.need-human-type', function () {
                var selectedValue = $(this).val();
                console.log('AA selectedValue : ', selectedValue)
                var $need_specialization = $(this).closest('div[data-repeater-item]').find('.need-specialization');
                if (selectedValue) {
                    console.log('BB selectedValue : ', selectedValue)
                    $.ajax({
                        type: 'POST',
                        url: BASE_URL + '/tasks/get_specialization',
                        data: {'HUMAN_TYPE': selectedValue, "_token": TOKEN},
                        dataType: 'json',
                        async: false,
                        success: function (result) {
                            // let html = JSON.stringify(result.data)
                            console.log('CC i : ', i)

                            console.log('RRRR : ', result_arr)
                            console.log('result.data ', result.data)
                            var select = $need_specialization;
                            select.empty();
                            select.html('');
                            select.attr('disabled', false);
                            select.append('<option value="">Select an option</option>');
                            $.each(result.data, function (key, value) {
                                console.log(i, result_arr.length);
                                if( i < result_arr.length){
                                    console.log('YYYYYYY : ', result_arr.length);
                                select.append('<option value="' + value.id + '"' + (value.id === result_arr[i]['specialization_id'] ? ' selected' : '') + '>' + value.name + '</option>');
                                }else{
                                    console.log('XXXXXX')
                                    select.append('<option value="' + value.id + '">' + value.name + '</option>');

                                }


                            });
                            select.select2();
                            console.log('i ', i)
                            i++;
                        },
                        error: function (e) {
                            console.log('error : ', e)
                        }
                    });
                }
            });

        }
    });

    // Initial binding for the existing first select elements
    $('.need-human-type').trigger('change');
});


