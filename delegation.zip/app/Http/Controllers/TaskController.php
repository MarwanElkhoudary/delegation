<?php

namespace App\Http\Controllers;

use App\Http\Resources\TaskResource;
use App\Models\Device;
use App\Models\Disposable;
use App\Models\Drug;
use App\Models\HumanType;
use App\Models\MedicalNeed;
use App\Models\Recommendation;
use App\Models\Specialization;
use App\Models\StatusTask;
use App\Models\Target;
use App\Models\Task;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Vtiful\Kernel\Excel;
use App\Exports\TasksExport;
use Carbon\Carbon;

class TaskController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $hospital = null;

        if (Auth()->user()->role_id == 1) {
            return view('task.index');
        } elseif (Auth()->user()->role_id == 2) {
            return view('task.administration.index');

        }
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $targets = Target::all();
        $human_types = HumanType::all();
        $specializations = Specialization::all();
//       dd($targets);
        return view('task.add', compact(array('targets', 'human_types', 'specializations')));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // Do validation later
        $validated = $request->validate([
            'specialization' => 'required|exists:specializations,id',
            'specialization_target' => 'required|exists:specializations,id',
            'contact_name' => 'required|string|max:255|min:10',
            'contact_phone' => 'phone',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after:start_date',
        ], [
                'contact_phone.phone' => 'Please enter a valid mobile number',
            ]
        );


        $input = $request->only('specialization', 'contact_name', 'contact_phone', 'specialization_target', 'start_date',
            'end_date', 'medical_needs_list', 'priority', 'devices_needed', 'drugs_needed', 'disposables','recommendation_team', 'recommendation_doctor');

        $startDate = Carbon::createFromFormat('Y-m-d',  $input['start_date']);
        $endDate = Carbon::createFromFormat('Y-m-d',  $input['end_date']);

        $input['hospital_id'] = Auth()->user()->hospital_id;
        $input['target_id'] = $request['specialization']; //temp
        $input['request_target_id'] = $request['specialization_target']; //temp
        $input['status_id'] = 1;
//        dd($input);

        if(array_key_exists('recommendation_team', $input )){
            $input['recommendation_team'] = $input['recommendation_team'];
        }else{
            $input['recommendation_team'] = null;
        }

        if(array_key_exists('recommendation_doctor', $input )){
            $input['recommendation_doctor'] = $input['recommendation_doctor'];
        }else{
            $input['recommendation_doctor'] = null;
        }

        if(array_key_exists('devices_needed', $input )){
            $input['devices_needed'] = $input['devices_needed'];
        }else{
            $input['devices_needed'] = null;
        }

        if(array_key_exists('drugs_needed', $input )){
            $input['drugs_needed'] = $input['drugs_needed'];
        }else{
            $input['drugs_needed'] = null;
        }

        if(array_key_exists('disposables', $input )){
            $input['disposables'] = $input['disposables'];
        }else{
            $input['disposables'] = null;
        }

//        dd($input['recommendation_team']);
//        dd($input['recommendation_doctor']);

        $task = Task::create($input);


        $task->medicalNeeds()->createMany($request->medical_needs_list);

        $recommendation_team =  $input['recommendation_team'];
        $recommendation_doctor =  $input['recommendation_doctor'];

        if (!is_null($recommendation_team) && $recommendation_team !== '' && !is_null($recommendation_doctor) && $recommendation_doctor !== '') {
            $recom = [
                'recommendation_team' =>  $input['recommendation_team'],
                'recommendation_doctor' => $input['recommendation_doctor'],
                'user_id' => auth()->user()->id,
                'task_id' => $task->id,
            ];

            Recommendation::create($recom);

        }

        $devices_needed = $input['devices_needed']; // Get the input from a request

        if (!is_null($devices_needed) && $devices_needed !== '') {
            // If the column is not null and not an empty string, proceed to create a new record
            $devices = [
                'description' => $input['devices_needed'],
                'task_id' => $task->id,
            ];

            Device::create($devices);
        }

        $drugs_needed = $input['drugs_needed']; // Get the input from a request

        if (!is_null($drugs_needed) && $drugs_needed !== '') {
            // If the column is not null and not an empty string, proceed to create a new record
            $drugs = [
                'description' => $input['drugs_needed'],
                'task_id' => $task->id,
            ];
            Drug::create($drugs);
        }

        $disposables = $input['disposables']; // Get the input from a request

        if (!is_null($disposables) && $disposables !== '') {
            // If the column is not null and not an empty string, proceed to create a new record
            $disposable = [
                'description' => $input['disposables'],
                'task_id' => $task->id,
            ];
            Disposable::create($disposable);

        }

        return redirect('/tasks/')->with('message', 'Your data has been saved successfully!');
        // dd($task->load('medicalNeeds'));

    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $statuses = StatusTask::all();
        $task = Task::where('id', $id)->first();

        return view('task.show_task', compact('task', 'statuses'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        $targets = Target::all();
        $human_types = HumanType::all();
        $specializations = Specialization::all();
        $task = Task::with('recommendation', 'device', 'drug', 'disposable')->findOrFail($id);
//        $task = Task::with('device')->findOrFail($id);
//        $task = Task::with('drug')->findOrFail($id);
//        $task = Task::with('disposable')->findOrFail($id);
//        dd($task);
//        $task->hospital_id = 2;

        if(Auth::user()->hospital_id != $task->hospital_id){
            abort(403, 'You do not have permission to edit this task.');
        }
//        dd($task->hospital_id);
        return view('task.edit_task', compact(array('targets', 'human_types', 'specializations', 'task')));
    }

    /**
     * Update the specified resource in storage.
     */
//    public function update(Request $request, Task $task)
    public function update(Request $request, $id)
    {
        $input = $request->only('contact_name', 'contact_phone', 'start_date',
            'end_date', 'priority');

//        dd($request);

        $input['hospital_id'] = Auth()->user()->hospital_id;
        $input['target_id'] = $request['specialization']; //temp
        $input['request_target_id'] = $request['specialization_target']; //temp
        $input['status_id'] = 1;
        $medicalNeedList_array = $request->only('medical_needs_list');
        $recom_array = $request->only('recommendation_team', 'recommendation_doctor');
        $device_array = $request->only('devices_needed');
        $drug_array = $request->only('drugs_needed');
        $disposable_array = $request->only('disposables');
        $flaq_update = Task::where('id', $id)->update($input);
//        dd($recom_array);
        if($flaq_update){
//            dd();
            $task = Task::findOrFail($id);
            $rowsDeleted = MedicalNeed::where('task_id', $id)->delete();

           $task->medicalNeeds()->createMany($medicalNeedList_array['medical_needs_list']);

        }


        $devices_task = Device::where('task_id', $id)->get();
        $drugs_task = Drug::where('task_id', $id)->get();
        $disposables_task = Disposable::where('task_id', $id)->get();
        $recommendatons_task = Recommendation::where('task_id', $id)->get();

        if($recommendatons_task->isEmpty()){
            $recommendatons = Recommendation::where('task_id', $id)->updateOrCreate(['recommendation_team' => $recom_array['recommendation_team'], 'recommendation_doctor'=> $recom_array['recommendation_doctor'],'task_id' => $id, 'user_id'=> Auth::user()->id]);
        }else{
            $recommendatons = Recommendation::where('task_id', $id)->update(['recommendation_team' => $recom_array['recommendation_team'], 'recommendation_doctor'=> $recom_array['recommendation_doctor'],'task_id' => $id, 'user_id'=> Auth::user()->id]);
        }


        if($devices_task->isEmpty()){
            $devices = Device::where('task_id', $id)->updateOrCreate(['description' => $device_array['devices_needed'], 'task_id' => $id]);
        }else{
            $devices = Device::where('task_id', $id)->update(['description' => $device_array['devices_needed'], 'task_id' => $id]);
        }

        if($drugs_task->isEmpty()){
            $drugs = Drug::where('task_id', $id)->updateOrCreate(['description' => $drug_array['drugs_needed'], 'task_id' => $id]);
        }else{
            $drugs = Drug::where('task_id', $id)->update(['description' => $drug_array['drugs_needed'], 'task_id' => $id]);
        }

        if($disposables_task->isEmpty()){
            $disposables  = Disposable::where('task_id', $id)->updateOrCreate(['description' => $disposable_array['disposables'], 'task_id' => $id]);
        }else{
            $disposables  = Disposable::where('task_id', $id)->update(['description' => $disposable_array['disposables'], 'task_id' => $id]);
        }

        return redirect('/tasks/')->with('message_edit', 'Your data has been saved successfully!');

    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        $delete_task = Task::destroy($id);

//        dd($delete_task);

        if ($delete_task) {

            return redirect('/tasks/')->with('message_delete', 'The task has been deleted successfully!');

        }
    }

    public function edit_task_status(Request $request, $id)
    {
//        echo 'this is id staus tasks function : '. $id;
        $task_status = $request->input('task_status');
        $reason = $request->input('reason');
        $priority = $request->input('priority');

        $task = Task::findOrFail($id);
        $task->priority = $request->input('priority');
        $task->note = $request->input('reason');
        $task->status_id = $request->input('task_status');

        $task->save();

//        return response()->json(['message' => 'Task status updated successfully!']);
        return redirect('tasks/view_task/'.$id)->with('message', 'Task status updated successfully!');

    }

    public function get_specialization(Request $request)
    {

        $data = $request->all();
        $data = $data['HUMAN_TYPE'];

        // echo "<pre>";print_r($data);die;
        $spec = Specialization::where('human_type_id', $data)->get();

        return response()->json([
            'status' => 'success',
            'data' => $spec,
//        'data' =>$data,
            'message' => 'Information saved successfully!'
        ], 200);

    }

    public function list()
    {

        //  $tasks = Task::with('medicalNeeds'  , 'RequestTarget' ,'target')->get();
        if (Auth()->user()->role_id == 2) {

            $tasks = Task::all();
            return response()->json([
                'data' => TaskResource::collection($tasks)
            ]);
        } elseif (Auth()->user()->role_id == 1) {

            $tasks = Task::where('hospital_id', (Auth()->user()->hospital_id))->get();
            return response()->json([
                'data' => TaskResource::collection($tasks)
            ]);
        }


    }
    public function medical_needs($id){
//        $task_id = $request->input('TASK_ID'); // Replace 'param1' with your actual parameter name
//        dd('dsfsfsfs: ' . $id);
        $medicalNeeds = MedicalNeed::where('task_id', $id)->get();
//        print_r($medicalNeeds);
        return response()->json($medicalNeeds);
    }


//    public function export_excel()
//    {
//        return Excel::download(new ExportTask, 'tasks.xlsx');
//    }

    public function export()
    {

        return \Maatwebsite\Excel\Facades\Excel::download(new TasksExport(Auth()->user()->hospital_id), 'tasks' . time() . '.xlsx');

    }
}
