<?php

use App\Http\Controllers\ProfileController;
use App\Http\Controllers\TaskController;
use Illuminate\Support\Facades\Route;

Route::post('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

//Route::post('/get_specialization', function () { return 'ffffffffffff'; });
Route::get('/', [TaskController::class,'index'])->middleware(['auth', 'verified']); // for task listing

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    Route::controller(TaskController::class)->prefix('tasks')->name('task.')->group(function () {
        Route::get('/', 'index')->name('index'); // for task listing
        Route::get('/export', 'export')->name('export'); // for task listing
        Route::get('/add', 'create')->name('create');
        Route::get('/view_task/{id}', 'show');
        Route::get('/edit_task/{id}', 'edit');
        Route::put('/edit_task_status/{id}', 'edit_task_status')->name('edit_task_status');
        Route::put('/task_update/{id}', 'update')->name('update');
        Route::get('/delete_task/{id}', 'destroy');
        Route::post('/', 'store')->name('store');
        Route::post('/get_specialization', 'get_specialization');
        Route::post('/list', 'list');
        Route::get('/medical_needs/{task_is}', 'medical_needs');
    });
});

require __DIR__.'/auth.php';
