<script src="{{ asset('assets')  }}/plugins/global/plugins.bundle.js"></script>
<script src="{{ asset('assets')  }}/js/scripts.bundle.js"></script>
