
@extends('master')

@section('css')
    <link href="{{ asset('assets')  }}/plugins/custom/datatables/datatables.bundle.css" rel="stylesheet"
          type="text/css"/>


@endsection

@section('role_user', 'Hospital Account')
@section('main-title')
    <a href="{{ route('task.index') }}">Tasks</a>
@endsection
@section('sub-title', 'Show Task')


@section('content')

    <div class="tab-content">
        <!--begin::Tab pane-->

        <div class="tab-pane fade show active" id="kt_ecommerce_add_product_general" role="tab-panel">
            <div class="d-flex flex-column gap-7 gap-lg-10">
                <!--begin::Card-->
                <div class="card card-flush pt-3 mb-5 mb-xl-10">
                    <!--begin::Card body-->
                    <div class="card-body pt-3">
                        <!--begin::Section-->
                        <div class="mb-10">
                            <!--begin::Title-->
                            <h5 class="mb-4">Human Resources Info: </h5>
                            <!--end::Title-->
                            <!--begin::Details-->
                            <div class="d-flex flex-wrap py-5">
                                <!--begin::Row-->
                                <div class="flex-equal me-5">
                                    <!--begin::Details-->
                                    <table class="table fs-6 fw-semibold gs-0 gy-2 gx-2 m-0">
                                        <!--begin::Row-->
                                        <tr>
                                            <td class="text-gray-500 min-w-175px w-175px">Hospital Name:</td>
                                            <td class="text-gray-800 min-w-200px">
                                                <span class="badge badge-light-dark">{{$task->hospital->name}}</span>
                                            </td>
                                        </tr>
                                        <!--end::Row-->
                                        <!--begin::Row-->
                                        <tr>
                                            <td class="text-gray-500">Contact Person:</td>
                                            <td class="text-gray-800">

                                                <span class="badge badge-light-primary">{{$task->contact_name}}</span>

                                            </td>
                                        </tr>
                                        <!--end::Row-->
                                        <!--begin::Row-->
                                        <tr>
                                            <td class="text-gray-500">Target Specialization:</td>
                                            <td class="text-gray-800">

                                                <span class="badge badge-light-info">  {{$task->target->name}}</span>

                                            </td>
                                        </tr>
                                        <!--end::Row-->
                                        <!--begin::Row-->
                                        <tr>
                                            <td class="text-gray-500">Start Period:</td>
                                            <td class="text-gray-800">
                                                <span class="badge badge-light-success"> {{$task->start_date}}</span>
                                            </td>
                                        </tr>
                                        <!--end::Row-->
                                    </table>
                                    <!--end::Details-->
                                </div>
                                <!--end::Row-->
                                <!--begin::Row-->
                                <div class="flex-equal">
                                    <!--begin::Details-->
                                    <table class="table fs-6 fw-semibold gs-0 gy-2 gx-2 m-0">
                                        <!--begin::Row-->
                                        <tr>
                                            <td class="text-gray-500 min-w-175px w-175px">Specialization:</td>
                                            <td class="text-gray-800 min-w-200px">
                                                <span
                                                    class="badge badge-light-info"> {{$task->requestTarget->name}}</span>


                                            </td>
                                        </tr>
                                        <!--end::Row-->
                                        <!--begin::Row-->
                                        <tr>
                                            <td class="text-gray-500">Contact Phone:</td>
                                            <td class="text-gray-800">
                                                <span class="badge badge-light-primary">{{$task->contact_phone}}</span>

                                            </td>
                                        </tr>
                                        <!--end::Row-->
                                        <!--begin::Row-->

                                        <tr>
                                            <td class="text-gray-500">Status Task:</td>
                                            <td class="text-gray-800">
                                                <span class="badge badge-light-warning">{{$task->status->name}}</span>
                                            </td>
                                            {{--                                            <td class="text-gray-800">{{$task->status->name}}</td>--}}
                                        </tr>
                                        <!--end::Row-->
                                        <!--begin::Row-->
                                        <tr>
                                            <td class="text-gray-500">End Date:</td>
                                            <td class="text-gray-800">
                                                <span class="badge badge-light-success"> {{$task->end_date}}</span>
                                            </td>
                                        </tr>
                                        <!--end::Row-->
                                    </table>
                                    <!--end::Details-->
                                </div>
                                <!--end::Row-->
                            </div>
                            <!--end::Row-->
                        </div>
                        <!--end::Section-->
                        <!--begin::Section-->
                        <div class="mb-10">
                            <!--begin::Title-->
                            <h5 class="mb-4">Medical Need Info:</h5>
                            <!--end::Title-->
                            <!--begin::Product table-->
                            <div class="table-responsive">
                                <!--begin::Table-->
                                <table class="table align-middle table-row-dashed fs-6 gy-4 mb-0">
                                    <!--begin::Table head-->
                                    <thead>
                                    <!--begin::Table row-->
                                    <tr class="border-bottom border-gray-200 text-start text-gray-500 fw-bold fs-7 text-uppercase gs-0">
                                        <th class="min-w-150px">specialization</th>
                                        <th class="min-w-125px">Count</th>
                                        <th class="min-w-125px">Note</th>
                                    </tr>
                                    <!--end::Table row-->
                                    </thead>
                                    <!--end::Table head-->
                                    <!--begin::Table body-->
                                    <tbody class="fw-semibold text-gray-800">
                                    @foreach($task->medicalNeeds as $item)
                                        <tr>
                                            <td>
                                                <label
                                                    class="w-150px"> {{$item->specialization->humanType->name}} </label>
                                                <div
                                                    class="fw-normal text-gray-600">{{$item->specialization->name}}</div>
                                            </td>
                                            <td>
                                                <span class="badge badge-light-danger">{{$item->count}}</span>
                                            </td>
                                            <td>  {{$item->note}}</td>

                                        </tr>
                                    @endforeach

                                    </tbody>
                                    <!--end::Table body-->
                                </table>
                                <!--end::Table-->
                            </div>
                            <!--end::Product table-->
                        </div>
                        <!--end::Section-->

                        <!--begin::Section-->
                        <div class="mb-10">
                            <!--begin::Title-->
                            <h5 class="mb-4">Others Info:</h5>
                            <!--end::Title-->

                            <!--begin::Section-->
                            <div class="m-0">
                                <!--begin::Heading-->
                                <div class="d-flex align-items-center collapsible py-3 toggle mb-0"
                                     data-bs-toggle="collapse" data-bs-target="#kt_job_1_1">
                                    <!--begin::Icon-->
                                    <div class="btn btn-sm btn-icon mw-20px btn-active-color-primary me-5">
                                        <i class="ki-outline ki-minus-square toggle-on text-primary fs-1"></i>
                                        <i class="ki-outline ki-plus-square toggle-off fs-1"></i>
                                    </div>
                                    <!--end::Icon-->
                                    <!--begin::Title-->
                                    <h4 class="text-gray-700 fw-bold cursor-pointer mb-0">Instrumental & Devices
                                        Needed</h4>
                                    <!--end::Title-->
                                </div>
                                <!--end::Heading-->
                                <!--begin::Body-->
                                <div id="kt_job_1_1" class="collapse show fs-6 ms-1">
                                    <!--begin::Item-->
                                    <div class="mb-4">
                                        <!--begin::Item-->
                                        <div class="d-flex align-items-center ps-10 mb-n1">
                                            <!--begin::Bullet-->
                                            <span class="bullet me-3"></span>
                                            <!--end::Bullet-->
                                            <!--begin::Label-->
                                            {{--                                            {{$task}}--}}
                                            <div
                                                class="text-gray-600 fw-semibold fs-6">{{$task->device?->description}}</div>
                                            <!--end::Label-->
                                        </div>
                                        <!--end::Item-->
                                    </div>
                                    <!--end::Item-->
                                </div>
                                <!--end::Content-->
                                <!--begin::Separator-->
                                <div class="separator separator-dashed"></div>
                                <!--end::Separator-->
                            </div>
                            <!--end::Section-->
                            <!--begin::Section-->
                            <div class="m-0">
                                <!--begin::Heading-->
                                <div class="d-flex align-items-center collapsible py-3 toggle collapsed mb-0"
                                     data-bs-toggle="collapse" data-bs-target="#kt_job_1_2">
                                    <!--begin::Icon-->
                                    <div class="btn btn-sm btn-icon mw-20px btn-active-color-primary me-5">
                                        <i class="ki-outline ki-minus-square toggle-on text-primary fs-1"></i>
                                        <i class="ki-outline ki-plus-square toggle-off fs-1"></i>
                                    </div>
                                    <!--end::Icon-->
                                    <!--begin::Title-->
                                    <h4 class="text-gray-700 fw-bold cursor-pointer mb-0">Pharmacitical & Drugs
                                        Needed</h4>
                                    <!--end::Title-->
                                </div>
                                <!--end::Heading-->
                                <!--begin::Body-->
                                <div id="kt_job_1_2" class="collapse fs-6 ms-1">
                                    <!--begin::Item-->
                                    <div class="mb-4">
                                        <!--begin::Item-->
                                        <div class="d-flex align-items-center ps-10 mb-n1">
                                            <!--begin::Bullet-->
                                            <span class="bullet me-3"></span>
                                            <!--end::Bullet-->
                                            <!--begin::Label-->
                                            <div
                                                class="text-gray-600 fw-semibold fs-6">{{$task->drug?->description}}</div>
                                            <!--end::Label-->
                                        </div>
                                        <!--end::Item-->
                                    </div>
                                    <!--end::Item-->
                                </div>
                                <!--end::Content-->
                                <!--begin::Separator-->
                                <div class="separator separator-dashed"></div>
                                <!--end::Separator-->
                            </div>
                            <!--end::Section-->
                            <!--begin::Section-->
                            <div class="m-0">
                                <!--begin::Heading-->
                                <div class="d-flex align-items-center collapsible py-3 toggle collapsed mb-0"
                                     data-bs-toggle="collapse" data-bs-target="#kt_job_1_3">
                                    <!--begin::Icon-->
                                    <div class="btn btn-sm btn-icon mw-20px btn-active-color-primary me-5">
                                        <i class="ki-outline ki-minus-square toggle-on text-primary fs-1"></i>
                                        <i class="ki-outline ki-plus-square toggle-off fs-1"></i>
                                    </div>
                                    <!--end::Icon-->
                                    <!--begin::Title-->
                                    <h4 class="text-gray-700 fw-bold cursor-pointer mb-0">Disposables</h4>
                                    <!--end::Title-->
                                </div>
                                <!--end::Heading-->
                                <!--begin::Body-->
                                <div id="kt_job_1_3" class="collapse fs-6 ms-1">
                                    <!--begin::Item-->
                                    <div class="mb-4">
                                        <!--begin::Item-->
                                        <div class="d-flex align-items-center ps-10 mb-n1">
                                            <!--begin::Bullet-->
                                            <span class="bullet me-3"></span>
                                            <!--end::Bullet-->
                                            <!--begin::Label-->
                                            <div
                                                class="text-gray-600 fw-semibold fs-6">{{$task->disposable?->description}}</div>
                                            <!--end::Label-->
                                        </div>
                                        <!--end::Item-->
                                    </div>
                                    <!--end::Item-->
                                </div>
                                <!--end::Content-->
                                <!--begin::Separator-->
                                <div class="separator separator-dashed"></div>
                                <!--end::Separator-->
                            </div>
                            <!--end::Section-->
                            <!--begin::Section-->
                            <div class="m-0">
                                <!--begin::Heading-->
                                <div class="d-flex align-items-center collapsible py-3 toggle collapsed mb-0"
                                     data-bs-toggle="collapse" data-bs-target="#kt_job_1_4">
                                    <!--begin::Icon-->
                                    <div class="btn btn-sm btn-icon mw-20px btn-active-color-primary me-5">
                                        <i class="ki-outline ki-minus-square toggle-on text-primary fs-1"></i>
                                        <i class="ki-outline ki-plus-square toggle-off fs-1"></i>
                                    </div>
                                    <!--end::Icon-->
                                    <!--begin::Title-->
                                    <h4 class="text-gray-700 fw-bold cursor-pointer mb-0">Recommendition</h4>
                                    <!--end::Title-->
                                </div>
                                <!--end::Heading-->
                                <!--begin::Body-->
                                <div id="kt_job_1_4" class="collapse fs-6 ms-1">
                                    <!--begin::Item-->
                                    <div class="mb-4">
                                        <!--begin::Item-->
                                        <div class="d-flex align-items-center ps-10 mb-n1">
                                            <!--begin::Bullet-->
                                            <span class="bullet me-3"></span>
                                            <!--end::Bullet-->
                                            <!--begin::Label-->
                                            <div class="text-gray-600 fw-semibold fs-6">Team
                                                Recommendition: {{$task->recommendation?->recommendation_team}}
                                            </div>
                                            <!--end::Label-->
                                        </div>
                                        <!--end::Item-->
                                    </div>
                                    <!--end::Item-->
                                    <!--begin::Item-->
                                    <div class="mb-4">
                                        <!--begin::Item-->
                                        <div class="d-flex align-items-center ps-10 mb-n1">
                                            <!--begin::Bullet-->
                                            <span class="bullet me-3"></span>
                                            <!--end::Bullet-->
                                            <!--begin::Label-->
                                            <div class="text-gray-600 fw-semibold fs-6">Doctor
                                                Recommendition: {{$task->recommendation?->recommendation_doctor}}</div>
                                            <!--end::Label-->
                                        </div>
                                        <!--end::Item-->
                                    </div>
                                    <!--end::Item-->


                                </div>
                                <!--end::Content-->
                            </div>
                            <!--end::Section-->

                        </div>
                        <!--end::Section-->
                    </div>
                    <!--end::Card body-->
                </div>
                <!--end::Card-->

                <!--begin::Card-->
                <!-- Check if the user is authenticated -->
                <?php
                if (Auth::user()->role_id == 2) {
                    ?>

                <div class="card card-flush pt-3 mb-5 mb-xl-10">

                    <!--begin::Card body-->
                    <div class="card-body pt-3">
                        <!--begin::Section-->

                        @if (session('message'))
                        <!--begin::Alert-->
                        <div class="alert alert-success d-flex align-items-center p-5">
                            <!--begin::Icon-->
                            <i class="ki-duotone ki-shield-tick fs-2hx text-success me-4"><span class="path1"></span><span class="path2"></span></i>
                            <!--end::Icon-->

                            <!--begin::Wrapper-->
                            <div class="d-flex flex-column">
                                <!--begin::Title-->
                                <h4 class="mb-1 text-dark">Success</h4>
                                <!--end::Title-->

                                <!--begin::Content-->
                                <span> {{ session('message') }}</span>
                                <!--end::Content-->
                            </div>
                            <!--end::Wrapper-->
                        </div>
                        <!--end::Alert-->
                        @endif
                        <div class="mb-10">
                            <!--begin::Title-->
                            <h5 class="mb-4">Task Management: </h5>
                            <!--end::Title-->
                            <!--begin::Details-->
{{--                            {{$task}}--}}
                            <form action="{{route('task.edit_task_status', [$task->id]) }}" class="form mb-15" method="post"
                                  id="kt_careers_form">
                                @csrf
                                @method('PUT')                                <!--begin::Input group-->
                                <div class="card-flush py-4">

                                    <!--begin::Card body-->
                                    <div class="card-body pt-0">

                                        <div class="d-flex flex-column mb-5 fv-row">
                                            <!--begin::Label-->
                                            <label class="d-flex align-items-center fs-5 fw-semibold mb-2">
                                                <span class="">Task Status</span>
                                                <span class="ms-1" data-bs-toggle="tooltip"
                                                      title="selected task status">
                                                            </span>
                                            </label>
                                            <!--end::Label-->
                                            <!--begin::Select-->
                                            <select required id="task_status"
                                                    name="task_status" data-control="select2"
                                                    class="form-select form-select-solid">
                                                @if(count($statuses) >0)
                                                    @foreach($statuses as $status)
                                                        {{--                                            <option value="{{$target->id}}" {{ old('specialization') === $target->id ? 'selected' : '' }}>{{$target->name}}</option>--}}
                                                        <option
                                                            value="{{$status->id}}" {{ old('task_status', $task->status_id) == $status->id ? "selected" :""}}>{{$status->name}}</option>
                                                    @endforeach
                                                @endif
                                            </select>
                                            <!--end::Select-->

                                        </div>

                                        <!--begin::Input group-->

                                        <div class="d-flex flex-column mb-5 fv-row " id="reason"
                                             <?php if(!empty($task->note)) {?>
                                             style="display: block !important;"
                                                <?php }else { ?> style="display: none !important;" <?php } ?> >

                                                <!--begin::Label-->
                                            <label class="d-flex align-items-center fs-5 fw-semibold mb-2" >
                                                <span class="">Reason</span>
                                                <span class="ms-1" data-bs-toggle="tooltip"
                                                      title="selected priority">
                                                            </span>
                                            </label>
                                            <!--end::Label-->
                                            <!--begin::Textarea-->
                                            <textarea class="form-control form-control-solid" rows="1" id="myTextarea"
                                                      name="reason"
                                                      placeholder="">{{old('reason', $task->note)}}</textarea>
                                            <!--end::Textarea-->
                                        </div>
                                        <!--end::Input group-->

                                        <!--begin::Input group-->
                                        <div class="d-flex flex-column mb-5 fv-row">
                                            <!--begin::Label-->
                                            <label class="d-flex align-items-center fs-5 fw-semibold mb-2">
                                                <span class="">Priority</span>
                                                <span class="ms-1" data-bs-toggle="tooltip"
                                                      title="selected priority">
                                                            </span>
                                            </label>
                                            <!--end::Label-->
                                            <!--begin::Select-->
                                            <select name="priority" data-control="select2"
                                                    data-placeholder="Select a priority..."
                                                    class="form-select form-select-solid">
                                                <option
                                                    value="Low" {{ old('priority', $task->priority) == "low" ? "selected" :""}}>
                                                    Low
                                                </option>
                                                <option
                                                    value="Medium" {{ old('priority', $task->priority) == "medium" ? "selected" :""}}>
                                                    Medium
                                                </option>
                                                <option
                                                    value="High" {{ old('priority', $task->priority) == "high" ? "selected" :""}}>
                                                    High
                                                </option>
                                            </select>
                                            <!--end::Select-->
                                        </div>
                                        <!--end::Input group-->

                                        <!--begin::Separator
                                        <div class="separator mb-8"></div>
                                        end::Separator-->
                                        <!--begin::Submit-->
                                        <button type="submit" class="btn btn-primary"
                                                id="kt_careers_submit_button">
                                            <!--begin::Indicator label-->
                                            <span class="indicator-label">Submit</span>
                                            <!--end::Indicator label-->
                                            <!--begin::Indicator progress-->
                                            <span class="indicator-progress">Please wait...
                                                            <span
                                                                class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                                            <!--end::Indicator progress-->
                                        </button>
                                        <!--end::Submit-->

                                    </div>
                                    <!--end::Card header-->
                                </div>
                                <!--end::General options-->

                            </form>
                            <!--end::Row-->
                        </div>
                        <!--end::Section-->

                    </div>
                    <!--end::Card body-->
                </div>
                <!--end::Card-->
                    <?php
                }
                ?>

            </div>
        </div>
        <!--end::Tab pane-->
    </div>

@endsection

@section('script')
    <!--end::Global Javascript Bundle-->
    <!--begin::Vendors Javascript(used for this page only)-->
    <script src="{{ asset('assets')  }}/plugins/custom/datatables/datatables.bundle.js"></script>
    <!--end::Vendors Javascript-->
    <!--begin::Custom Javascript(used for this page only)-->
    <script src="{{ asset('assets')  }}/js/widgets.bundle.js"></script>
    <script src="{{ asset('assets')  }}/js/custom/widgets.js"></script>
    <script src="{{ asset('assets')  }}/js/custom/apps/chat/chat.js"></script>
    <script src="{{ asset('assets')  }}/js/custom/utilities/modals/upgrade-plan.js"></script>
    <script src="{{ asset('assets')  }}/js/custom/utilities/modals/new-target.js"></script>
    <script src="{{ asset('assets')  }}/js/custom/utilities/modals/users-search.js"></script>
    <!--end::Custom Javascript-->
    <!--end::Javascript-->
@endsection

@section('js')
    <script src="{{ asset('assets')  }}/javascript/pages/show_task.js"></script>

@endsection


<!--end::Custom Javascript-->
